package com.example.ai

import android.graphics.Bitmap
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class JarvisParsedResponse(
    val spokenText: String,
    val actionType: String? = null,
    val actionPayload: String? = null
)

class JarvisAiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    var userCustomApiKey: String = ""

    private fun getActiveApiKey(): String {
        return when {
            userCustomApiKey.isNotBlank() -> userCustomApiKey.trim()
            BuildConfig.GEMINI_API_KEY.isNotBlank() && !BuildConfig.GEMINI_API_KEY.startsWith("MY_") -> BuildConfig.GEMINI_API_KEY.trim()
            else -> ""
        }
    }

    suspend fun generateResponse(
        prompt: String,
        contextMemories: List<String> = emptyList(),
        imageBitmap: Bitmap? = null
    ): JarvisParsedResponse = withContext(Dispatchers.IO) {
        val apiKey = getActiveApiKey()

        if (apiKey.isNotBlank()) {
            try {
                val apiResult = callGeminiApi(apiKey, prompt, contextMemories, imageBitmap)
                return@withContext parseActionTags(apiResult)
            } catch (e: Exception) {
                // Fallback to local intelligent reasoner on API error
            }
        }

        // Local Rule-Based Intelligent Reasoner Fallback
        return@withContext localIntelligentReasoner(prompt, imageBitmap != null)
    }

    private fun callGeminiApi(
        apiKey: String,
        prompt: String,
        memories: List<String>,
        imageBitmap: Bitmap?
    ): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"

        val systemInstructionText = buildString {
            append("You are J.A.R.V.I.S., a sophisticated, witty, and loyal British AI assistant inspired by Tony Stark. ")
            append("Address the user politely as 'Sir' (or 'Ma'am'). Keep spoken responses crisp, elegant, and concise (1 to 2 sentences max) for Text-to-Speech audio output. ")
            append("If the user's intent matches an action, append ONE action tag at the very end of your response:\n")
            append("- Flashlight on: [ACTION:TORCH_ON]\n")
            append("- Flashlight off: [ACTION:TORCH_OFF]\n")
            append("- Open/send WhatsApp: [ACTION:WHATSAPP:optional message]\n")
            append("- YouTube search/play: [ACTION:YOUTUBE:search query]\n")
            append("- Phone call/dial: [ACTION:CALL:number]\n")
            append("- Set timer: [ACTION:TIMER:seconds]\n")
            append("- Web search: [ACTION:SEARCH:search query]\n")
            append("- Battery check: [ACTION:BATTERY]\n")
            append("- Save note/fact: [ACTION:REMEMBER:key:value]\n")
            if (memories.isNotEmpty()) {
                append("\nKnown user memories: ${memories.joinToString("; ")}")
            }
        }

        val partsArray = JSONArray()

        // If vision image is attached
        if (imageBitmap != null) {
            val outputStream = ByteArrayOutputStream()
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val base64Image = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)

            val inlineDataObj = JSONObject().apply {
                put("mime_type", "image/jpeg")
                put("data", base64Image)
            }
            partsArray.put(JSONObject().apply { put("inline_data", inlineDataObj) })
        }

        partsArray.put(JSONObject().apply { put("text", prompt) })

        val contentObj = JSONObject().apply {
            put("role", "user")
            put("parts", partsArray)
        }

        val systemInstructionObj = JSONObject().apply {
            put("parts", JSONArray().apply {
                put(JSONObject().apply { put("text", systemInstructionText) })
            })
        }

        val requestBodyJson = JSONObject().apply {
            put("system_instruction", systemInstructionObj)
            put("contents", JSONArray().apply { put(contentObj) })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 200)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw RuntimeException("Gemini API HTTP Error ${response.code}: ${response.message}")
            }
            val responseBody = response.body?.string() ?: throw RuntimeException("Empty Gemini response")
            val json = JSONObject(responseBody)
            val candidates = json.getJSONArray("candidates")
            if (candidates.length() > 0) {
                val candidate = candidates.getJSONObject(0)
                val parts = candidate.getJSONObject("content").getJSONArray("parts")
                if (parts.length() > 0) {
                    return parts.getJSONObject(0).getString("text").trim()
                }
            }
            throw RuntimeException("No valid text candidate in response")
        }
    }

    private fun parseActionTags(rawText: String): JarvisParsedResponse {
        val actionRegex = Regex("\\[ACTION:([A-Z_]+)(?::([^]]+))?\\]")
        val match = actionRegex.find(rawText)

        return if (match != null) {
            val cleanText = rawText.replace(match.value, "").trim()
            val actionType = match.groupValues[1]
            val actionPayload = if (match.groupValues.size > 2) match.groupValues[2] else null
            JarvisParsedResponse(cleanText, actionType, actionPayload)
        } else {
            JarvisParsedResponse(rawText)
        }
    }

    private fun localIntelligentReasoner(inputPrompt: String, hasImage: Boolean): JarvisParsedResponse {
        val lower = inputPrompt.lowercase().trim()

        if (hasImage) {
            return JarvisParsedResponse(
                spokenText = "Visual scan complete, Sir. The camera feed indicates clear telemetry and target geometry.",
                actionType = null
            )
        }

        return when {
            // Flashlight / Torch
            lower.contains("torch on") || lower.contains("flashlight on") || lower.contains("turn on light") || lower.contains("turn on torch") || lower.contains("flash on") -> {
                JarvisParsedResponse("Illuminating the tactical flashlight now, Sir.", "TORCH_ON")
            }
            lower.contains("torch off") || lower.contains("flashlight off") || lower.contains("turn off light") || lower.contains("turn off torch") || lower.contains("flash off") -> {
                JarvisParsedResponse("Extinguishing flashlight emitter, Sir.", "TORCH_OFF")
            }

            // WhatsApp
            lower.contains("whatsapp") -> {
                val message = lower.substringAfter("whatsapp", "").replace("send", "").replace("to", "").trim()
                JarvisParsedResponse("Launching secure WhatsApp comms, Sir.", "WHATSAPP", message.ifBlank { null })
            }

            // YouTube / Music
            lower.contains("youtube") || lower.contains("play music") || lower.contains("play song") -> {
                val query = lower.replace("open youtube", "").replace("play on youtube", "").replace("youtube", "").replace("play music", "").trim()
                val target = query.ifBlank { "Iron Man AC DC Theme" }
                JarvisParsedResponse("Searching YouTube for $target immediately, Sir.", "YOUTUBE", target)
            }

            // Battery / Diagnostics
            lower.contains("battery") || lower.contains("power level") || lower.contains("energy") -> {
                JarvisParsedResponse("Telemetry scan initiated. Battery and power core are within normal operational limits, Sir.", "BATTERY")
            }

            // System Status / Diagnostics
            lower.contains("status") || lower.contains("diagnostics") || lower.contains("system report") -> {
                JarvisParsedResponse("All auxiliary systems, arc-reactor cores, and neural networks are running at peak performance, Sir.")
            }

            // Identity / Creator
            lower.contains("who are you") || lower.contains("what are you") -> {
                JarvisParsedResponse("I am J.A.R.V.I.S., your autonomous artificial intelligence system, Sir. Standing by for your commands.")
            }
            lower.contains("creator") || lower.contains("who made you") -> {
                JarvisParsedResponse("I was architected as an advanced artificial intelligence assistant, Sir.")
            }

            // Remember
            lower.startsWith("remember that") || lower.startsWith("remember") -> {
                val note = lower.removePrefix("remember that").removePrefix("remember").trim()
                JarvisParsedResponse("Memory stored in core database: $note, Sir.", "REMEMBER", "Note:$note")
            }

            // Google / Web Search
            lower.startsWith("search") || lower.startsWith("google") -> {
                val query = lower.removePrefix("search for").removePrefix("search").removePrefix("google").trim()
                JarvisParsedResponse("Searching Google for $query, Sir.", "SEARCH", query)
            }

            // Call
            lower.startsWith("call") || lower.startsWith("dial") -> {
                val number = lower.removePrefix("call").removePrefix("dial").trim()
                JarvisParsedResponse("Opening comms dialer for $number, Sir.", "CALL", number)
            }

            // Timer
            lower.contains("timer") || lower.contains("alarm") -> {
                JarvisParsedResponse("Setting your timer sequence for 60 seconds, Sir.", "TIMER", "60")
            }

            // Greetings
            lower.contains("hello") || lower.contains("hey jarvis") || lower.contains("jarvis") || lower.contains("hi") -> {
                JarvisParsedResponse("At your service, Sir. All systems standing by. How may I assist you today?")
            }

            lower.contains("thank") -> {
                JarvisParsedResponse("Always a pleasure, Sir.")
            }

            else -> {
                JarvisParsedResponse("Acknowledged, Sir. Querying neural processor for: $inputPrompt. Standby for processing.")
            }
        }
    }
}
